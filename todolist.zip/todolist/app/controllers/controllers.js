// here we define all the controllers that the app is using

// the main controller, lightly used for constant and value services
app.controller('AngularJSTodoListListAppController', 
    ["author", "version", function AngularJSTodoListListAppController(author, version) {
        this.author = author;
        this.version = version;
    }]
);

// user controller making use of the userService service
app.controller('userControllerWithService',
    ['$scope', '$http', '$routeParams', 'userService',
      function ($scope, $http, $routeParams, userService) {

        $scope.usersList = [];
        $scope.loading = true;
        $scope.loadingOneUser = true;
        $scope.user = {}; // used in case only one customer is selected

        $scope.init = function init() {
            $scope.loading = true;
            userService.getUsers().success(function (data) {
                $scope.usersList = data;
                $scope.loading = false;
            }).error(function (data) {
                $scope.loading = false;
                console.log('userControllerWithService.init():err:' + data);
            });

            // initialize the user in case a user is selected (by reading first the userId from route)
            $scope.loadingOneUser = true;
            var userId = ($routeParams.userId) ? parseInt($routeParams.userId) : 0;
            if (userId > 0) {
                userService.getUser(userId).success(function (data) {
                    $scope.user = data;
                    $scope.loadingOneUser = false;
                }).error(function (data) {
                    $scope.loadingOneUser = false;
                    console.log('userControllerWithService.init():err:' + data);
                });
            }

            if ($scope.usersList)
                console.log('usersList count ' + $scope.usersList.length);
        }

        $scope.insertUser = function () {
            var firstName = $scope.newUser.FirstName;
            var lastName = $scope.newUser.LastName;
            $scope.loading = true;
            userService.insertUser(firstName, lastName).
                success(function (data) {
                    // refresh users list
                    $scope.init();
                    $scope.loading = false;
                }).error(function (data) {
                    $scope.loading = false;
                    console.log('userControllerWithService.insertUser():err:' + data);
                });
            $scope.newUser.FirstName = '';
            $scope.newUser.LastName = '';
            if ($scope.usersList)
                console.log('usersList count ' + $scope.usersList.length);
        }

        $scope.deleteUser = function(userId) {
            $scope.loading = true;
            userService.deleteUser(userId).
                success(function (data) {
                    // refresh users list
                    $scope.init();
                    $scope.loading = false;
                }).error(function (data) {
                    $scope.loading = false;
                    console.log('userControllerWithService.deleteUser():err:' + data);
                });
            if ($scope.usersList)
                console.log('usersList count ' + $scope.usersList.length);
        }

        $scope.getUserFullName = function (user) {
            return user.FirstName + ' ' + user.LastName;
        }

        $scope.createTodo = function (userSelectedId, title, description, duedate) {
            $scope.loading = true;
            userService.createTodo(userSelectedId, title, description, duedate).
                success(function (data) {
                    // refresh users list
                    $scope.init();
                    $scope.loading = false;
                }).error(function (data) {
                    $scope.loading = false;
                    console.log('userControllerWithService.createTodo():err:' + data);
                });
            if ($scope.usersList)
                console.log('usersList count ' + $scope.usersList.length);
        }

        $scope.init();
    }]
);

// user controller making use of the userFactory service
app.controller('userControllerWithFactory',
    ['$scope', '$http', '$routeParams', 'userFactory',
      function ($scope, $http, $routeParams, userFactory) {

          $scope.usersList = [];
          $scope.loading = true;
          $scope.loadingOneUser = true;
          $scope.user = {}; // used in case only one customer is selected

          $scope.init = function init() {
              $scope.loading = true;
              userFactory.getUsers().success(function (data) {
                  $scope.usersList = data;
                  $scope.loading = false;
              }).error(function (data) {
                  $scope.loading = false;
                  console.log('userControllerWithService.init():err:' + data);
              });

              // initialize the user in case a user is selected (by reading first the userId from route)
              $scope.loadingOneUser = true;
              var userId = ($routeParams.userId) ? parseInt($routeParams.userId) : 0;
              if (userId > 0) {
                  userFactory.getUser(userId).success(function (data) {
                      $scope.user = data;
                      $scope.loadingOneUser = false;
                  }).error(function (data) {
                      $scope.loadingOneUser = false;
                      console.log('userControllerWithService.init():err:' + data);
                  });
              }

              if ($scope.usersList)
                  console.log('usersList count ' + $scope.usersList.length);
          }

          $scope.insertUser = function () {
              var firstName = $scope.newUser.FirstName;
              var lastName = $scope.newUser.LastName;
              $scope.loading = true;
              userFactory.insertUser(firstName, lastName).
                  success(function (data) {
                      // refresh users list
                      $scope.init();
                      $scope.loading = false;
                  }).error(function (data) {
                      $scope.loading = false;
                      console.log('userControllerWithService.insertUser():err:' + data);
                  });
              $scope.newUser.FirstName = '';
              $scope.newUser.LastName = '';
              if ($scope.usersList)
                  console.log('usersList count ' + $scope.usersList.length);
          }

          $scope.deleteUser = function (userId) {
              $scope.loading = true;
              userFactory.deleteUser(userId).
                  success(function (data) {
                      // refresh users list
                      $scope.init();
                      $scope.loading = false;
                  }).error(function (data) {
                      $scope.loading = false;
                      console.log('userControllerWithService.deleteUser():err:' + data);
                  });
              if ($scope.usersList)
                  console.log('usersList count ' + $scope.usersList.length);
          }

          $scope.getUserFullName = function (user) {
              return user.FirstName + ' ' + user.LastName;
          }

          $scope.createTodo = function (userSelectedId, title, description, duedate) {
              $scope.loading = true;
              userFactory.createTodo(userSelectedId, title, description, duedate).
                  success(function (data) {
                      // refresh users list
                      $scope.init();
                      $scope.loading = false;
                  }).error(function (data) {
                      $scope.loading = false;
                      console.log('userControllerWithService.createTodo():err:' + data);
                  });
              if ($scope.usersList)
                  console.log('usersList count ' + $scope.usersList.length);
          }

          $scope.init();
      }]
);

// user controller making use of the userProvider service
app.controller('userControllerWithProvider',
    ['$scope', '$http', '$routeParams', 'userProvider',
      function ($scope, $http, $routeParams, userProvider) {

          $scope.usersList = [];
          $scope.loading = true;
          $scope.loadingOneUser = true;
          $scope.user = {}; // used in case only one customer is selected

          $scope.init = function init() {
              $scope.loading = true;
              userProvider.getUsers().success(function (data) {
                  $scope.usersList = data;
                  $scope.loading = false;
              }).error(function (data) {
                  $scope.loading = false;
                  console.log('userControllerWithProvider.init():err:' + data);
              });

              // initialize the user in case a user is selected (by reading first the userId from route)
              $scope.loadingOneUser = true;
              var userId = ($routeParams.userId) ? parseInt($routeParams.userId) : 0;
              if (userId > 0) {
                  userProvider.getUser(userId).success(function (data) {
                      $scope.user = data;
                      $scope.loadingOneUser = false;
                  }).error(function (data) {
                      $scope.loadingOneUser = false;
                      console.log('userControllerWithProvider.init():err:' + data);
                  });
              }

              if ($scope.usersList)
                  console.log('usersList count ' + $scope.usersList.length);
          }

          $scope.insertUser = function () {
              var firstName = $scope.newUser.FirstName;
              var lastName = $scope.newUser.LastName;
              $scope.loading = true;
              userProvider.insertUser(firstName, lastName).
                  success(function (data) {
                      // refresh users list
                      $scope.init();
                      $scope.loading = false;
                  }).error(function (data) {
                      $scope.loading = false;
                      console.log('userControllerWithProvider.insertUser():err:' + data);
                  });
              $scope.newUser.FirstName = '';
              $scope.newUser.LastName = '';
              if ($scope.usersList)
                  console.log('usersList count ' + $scope.usersList.length);
          }

          $scope.deleteUser = function (userId) {
              $scope.loading = true;
              userProvider.deleteUser(userId).
                  success(function (data) {
                      // refresh users list
                      $scope.init();
                      $scope.loading = false;
                  }).error(function (data) {
                      $scope.loading = false;
                      console.log('userControllerWithProvider.deleteUser():err:' + data);
                  });
              if ($scope.usersList)
                  console.log('usersList count ' + $scope.usersList.length);
          }

          $scope.getUserFullName = function (user) {
              return user.FirstName + ' ' + user.LastName;
          }

          $scope.createTodo = function (userSelectedId, title, description, duedate) {
              $scope.loading = true;
              userProvider.createTodo(userSelectedId, title, description, duedate).
                  success(function (data) {
                      // refresh users list
                      $scope.init();
                      $scope.loading = false;
                  }).error(function (data) {
                      $scope.loading = false;
                      console.log('userControllerWithProvider.createTodo():err:' + data);
                  });
              if ($scope.usersList)
                  console.log('usersList count ' + $scope.usersList.length);
          }

          $scope.init();
      }]
);

// user controller making use of the userService service
app.controller('userControllerWithServiceLocalDB',
    ['$scope', '$http', '$routeParams', 'userServiceLocalDB',
      function ($scope, $http, $routeParams, userServiceLocalDB) {

        $scope.usersList = [];
        $scope.loading = true;
        $scope.loadingOneUser = true;
        $scope.user = {}; // used in case only one customer is selected

        $scope.init = function init() {
            $scope.usersList = userServiceLocalDB.getUsers();

            var userId = ($routeParams.userId) ? parseInt($routeParams.userId) : 0;
            if (userId > 0) {
                for (var i = $scope.usersList.length - 1; i >= 0; i--) {
                  if ($scope.usersList[i].Id === userId) {
                    $scope.user = $scope.usersList[i];
                    console.log($scope.user.Todos);
                  }                  
                }
            }

            if ($scope.usersList)
                console.log('usersList count ' + $scope.usersList.length);
        }

        $scope.insertUser = function () {
            var firstName = $scope.newUser.FirstName;
            var lastName = $scope.newUser.LastName;
            var user = { Id: $scope.usersList.length + 1, FirstName: firstName, LastName: lastName};
            $scope.usersList.push(user);
            $scope.newUser.FirstName = '';
            $scope.newUser.LastName = '';
            if ($scope.usersList)
                console.log('usersList count ' + $scope.usersList.length);
        }

        $scope.deleteUser = function(userId) {
            for (var i = $scope.usersList.length - 1; i >= 0; i--) {
                if ($scope.usersList[i].Id === userId) {
                    $scope.usersList.splice(i, 1);
                    break;
                }
            }
            if ($scope.usersList)
                console.log('usersList count ' + $scope.usersList.length);
        }

        $scope.getUserFullName = function (user) {
            return user.FirstName + ' ' + user.LastName;
        }

        $scope.createTodo = function (userSelectedId, title, description, duedate) {
            var todos = { title: title, description: description, duedate: duedate };
            for (var i = $scope.usersList.length - 1; i >= 0; i--) {
                if ($scope.usersList[i].Id === userSelectedId) {
                    console.log($scope.usersList[i]);
                    if ($scope.usersList[i]['Todos']) {
                      $scope.usersList[i]['Todos'].push(todos);
                    } else {
                      $scope.usersList[i]['Todos'] = [];
                      $scope.usersList[i]['Todos'].push(todos);
                    }
                }
            }
            if ($scope.usersList)
                console.log('usersList count ' + $scope.usersList.length);
        }

        $scope.init();
    }]
);
